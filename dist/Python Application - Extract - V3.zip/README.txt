To start the application, simple execute 'Dimensionality Reduction Program.exe'
This should generate the folders nessesary.

When the application is open, clicking `Load all CSV files` will load all the files in the data folder with the corresponding settings file.
.Csv and .data will be loaded

You can now drag and drop files into the program to load the data file.

Clicking 'Execute Reduction On All' will process all of the data with all the algorithms.

You can now view and edit the settings for all the files.

Clicking `Execute reduction algorithms` will run through all the reduction and classification iterations.
Aftet this has completed, it will generate graphs under the visualisation Tab.

If you edit the settings for a csv file, make sure to save them.

