To start the application, simple execute `main.exe`
This should generate the folders nessesary.

When the application is open, clicking `Load all CSV files` will load all the files in the data folder with the corresponding settings file.

You can now view and edit the settings for all the files.

Clicking `Execute reduction algorithms` will run through all the reduction and classification iterations.
Aftet this has completed, it will generate graphs under the visualisation Tab.

If you edit the settings for a csv file, make sure to save them.

Currently the application might run slow in some places, there also may be some random crashes.
Its an early version and i already have a list of things to add.

Planned Features:
More varients of graphs
Reduction and classificaion settings
Enabling, disabling and adding of new algorithms
Exporting all data to excel file
Exporting all graphs to image file
Exporting specific reduction data, colums/rows of data with a specific dimension.
Bug fixes, opimisaions, and visualisation changes.